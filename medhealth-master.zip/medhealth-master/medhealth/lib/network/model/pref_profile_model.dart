class PrefProfile {
  static String idUser = 'id_user';
  static String name = 'name';
  static String email = 'email';
  static String phone = 'phone';
  static String address = 'address';
  static String createdAt = 'created_at';
}
