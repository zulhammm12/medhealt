package com.example.medhealth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
